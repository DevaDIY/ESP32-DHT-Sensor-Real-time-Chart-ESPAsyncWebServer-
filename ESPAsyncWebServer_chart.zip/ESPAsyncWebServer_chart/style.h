const char style_css[] PROGMEM = R"rawliteral(
    body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      background: rgba(75, 192, 192, 0.2);
    }
    .chartMenu {
      width: 100vw;
      height: 60px;
      background: #1A1A1A;
      color: rgba(75, 192, 192, 1);
    }
    .chartMenu p {
      padding: 10px;
      font-size: 30px;
      text-align: center;
    }
    .chartCard {
      width: 100%;
      display: block;
      justify-content: center;
    }
    .chartBox {
      width: 90%;
      padding: 20px;
      margin: 10px auto;
      align-items: center;
      border-radius: 20px;
      border: solid 3px rgba(75, 192, 192, 1);
      background: white;
    }
    .sensorBox {
      width: 70%;
      padding: 5px 15px;
      margin: 10px auto;
      text-align: center;
      border-radius: 20px;
      border: solid 3px rgba(75, 192, 192, 1);
      background: white;
    }
    .sensorBox p {
      font-size: 42px; 
    }
    .units { 
      font-size: 16px; 
    } 
    .dht-labels{
      font-size: 20px;
      vertical-align: middle;
      padding-bottom: 15px;
    }
)rawliteral";
