const char index_html[] PROGMEM = R"rawliteral(
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-adapter-date-fns"></script>
    <title> Deva DIY </title>
    
  </head>
  <body>
    <div class="chartMenu">
      <p>โครงงาน ESP สถานีอากาศ</p>
    </div>
      
    <div class="chartCard">
      <div class="chartBox">
          <canvas id="myChart" style="height:55vh; width:80vw" ></canvas>
      </div>
      <div class="sensorBox">
        <p> 
          <i class="fas fa-thermometer-half" style="color:#059e8a;"></i>
          <span class="dht-labels">อุณหภูมิ เซลเซียส</span> 
          <span id="temperature" style="color:red">%VALUE_INPUT1%</span>
          <sup class="units">&deg;C</sup>
        </p>
      </div>
    </div>
    
    <script>
          
      const ctx = document.getElementById('myChart').getContext('2d');
      var chart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: [],
            datasets: [{
              label: 'อุณหภูมิ',
              data: [],
              borderWidth: 1,
            }]
          },
          options: {
            responsive: true,
            scales: {
              x: {
                type: 'time', // ตั้งค่า type เป็น 'time'
                time: {
                  unit: 'minute',
                  displayFormats: {
                    second: 'hh:mm' 
                  }
                },
                title: {
                  display: true,
                  text: 'เวลา'
                }
              },
              y: {           
                title: {
                  display: true,
                  text: 'องศาเซลเซียส (°C)'
                },
                ticks: {
                   stepSize: 0.2
                }
              }
            }
          }
    });

      setInterval(function addData() {
        var xhttp = new XMLHttpRequest();
          xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
              //อัพเดทเวลาในแกน X 
              let date = new Date().getTime();
              chart.data.labels.push(date);
  
              // เพิ่มข้อมูลใหม่ลงใน datasets ของ chart เมื่อเซอเวอร์ตอบกลับ
              newDataT = parseFloat(this.responseText);
              chart.data.datasets[0].data.push(newDataT);
              
              // เพิ่มข้อมูลใหม่ลงใน id=temperature หน้า html นี้ เมื่อเซอเวอร์ตอบกลับ
              document.getElementById("temperature").innerHTML = this.responseText;

              // ลบข้อมูลใน array data เมื่อเกิน 20 ค่า
              if (chart.data.datasets[0].data.length > 20) {
                chart.data.datasets[0].data.shift();
                chart.data.labels.shift();
              }            
                
            // อัพเดท chart
            chart.update();
            }
          };
          xhttp.open("GET", "/temperature", true);
          xhttp.send();
          
     }, 10000);  
    
    </script>

  </body>
</html>
)rawliteral";
